#include "glad/glad.h"
#include "glm/ext/matrix_transform.hpp"
#if defined(__APPLE__) || defined(__linux__)
 #include <SDL3/SDL.h>
 #include <SDL3/SDL_opengl.h>
#else
 #include <SDL.h>
 #include <SDL_opengl.h>
#endif
#include <cstdio>
#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>

#define GLM_FORCE_RADIANS
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "Camera.h"
#include "MapLoader.h"
#include "AnimationSystem.h"

int screenWidth = 800; 
int screenHeight = 600;  

bool keysCollected[5] = {false, false, false, false, false};

GLuint shaderProgram;
GLuint vao;
GLuint tex0, tex1;

int cubeStart, cubeVerts;
int knotStart, knotVerts;
int keyStart, keyVerts;

int loadModel(const char* filename, std::vector<float>& buffer) {
    std::ifstream modelFile;
    modelFile.open(filename);
    int numLines = 0;
    if (modelFile.is_open()){
        modelFile >> numLines;
    } else {
        printf("Failed to load model: %s\n", filename);
        return 0;
    }
    float val;
    for (int i = 0; i < numLines; i++){
        modelFile >> val;
        buffer.push_back(val);
    }
    modelFile.close();
    printf("Loaded model %s with %d vertices\n", filename, numLines/8);
    return numLines / 8;
}

int loadOBJ(const char* filename, std::vector<float>& buffer) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        printf("Failed to load OBJ: %s\n", filename);
        return 0;
    }
    std::vector<glm::vec3> positions;
    std::string line;
    int added = 0;
    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string prefix;
        ss >> prefix;
        if (prefix == "v") {
            glm::vec3 pos;
            ss >> pos.x >> pos.y >> pos.z;
            positions.push_back(pos);
        } else if (prefix == "f") {
            int v1, v2, v3;
            ss >> v1 >> v2 >> v3;
            v1--; v2--; v3--;
            if (v1 >= 0 && v1 < positions.size() &&
                v2 >= 0 && v2 < positions.size() &&
                v3 >= 0 && v3 < positions.size()) {
                glm::vec3 p1 = positions[v1];
                glm::vec3 p2 = positions[v2];
                glm::vec3 p3 = positions[v3];
                glm::vec3 edge1 = p2 - p1;
                glm::vec3 edge2 = p3 - p1;
                glm::vec3 normal = glm::normalize(glm::cross(edge1, edge2));
                buffer.push_back(p1.x); buffer.push_back(p1.y); buffer.push_back(p1.z);
                buffer.push_back(0.0f); buffer.push_back(0.0f);
                buffer.push_back(normal.x); buffer.push_back(normal.y); buffer.push_back(normal.z);
                buffer.push_back(p2.x); buffer.push_back(p2.y); buffer.push_back(p2.z);
                buffer.push_back(0.0f); buffer.push_back(0.0f);
                buffer.push_back(normal.x); buffer.push_back(normal.y); buffer.push_back(normal.z);
                buffer.push_back(p3.x); buffer.push_back(p3.y); buffer.push_back(p3.z);
                buffer.push_back(0.0f); buffer.push_back(0.0f);
                buffer.push_back(normal.x); buffer.push_back(normal.y); buffer.push_back(normal.z);
                added += 3;
            }
        }
    }
    file.close();
    printf("Loaded OBJ %s with %d vertices\n", filename, added);
    return added;
}

char* readShaderSource(const char* shaderFile){
    FILE *fp;
    long length;
    char *buffer;
    fp = fopen(shaderFile, "r");
    if (fp == NULL) return NULL;
    fseek(fp, 0, SEEK_END);
    length = ftell(fp);
    buffer = new char[length + 1];
    fseek(fp, 0, SEEK_SET);
    fread(buffer, 1, length, fp);
    buffer[length] = '\0';
    fclose(fp);
    return buffer;
}

GLuint InitShader(const char* vShaderFileName, const char* fShaderFileName){
    GLuint vertex_shader, fragment_shader;
    GLchar *vs_text, *fs_text;
    GLuint program;
    vertex_shader = glCreateShader(GL_VERTEX_SHADER);
    fragment_shader = glCreateShader(GL_FRAGMENT_SHADER);
    vs_text = readShaderSource(vShaderFileName);
    fs_text = readShaderSource(fShaderFileName);
    if (vs_text == NULL || fs_text == NULL) exit(1);
    const char *vv = vs_text;
    glShaderSource(vertex_shader, 1, &vv, NULL);
    glCompileShader(vertex_shader);
    const char *ff = fs_text;
    glShaderSource(fragment_shader, 1, &ff, NULL);
    glCompileShader(fragment_shader);
    program = glCreateProgram();
    glAttachShader(program, vertex_shader);
    glAttachShader(program, fragment_shader);
    glLinkProgram(program);
    return program;
}

void drawObject(glm::mat4 view, glm::mat4 proj, glm::mat4 model, int start, int verts, int texID, glm::vec3 color) {
    GLint uniView = glGetUniformLocation(shaderProgram, "view");
    GLint uniProj = glGetUniformLocation(shaderProgram, "proj");
    GLint uniModel = glGetUniformLocation(shaderProgram, "model");
    GLint uniTexID = glGetUniformLocation(shaderProgram, "texID");
    GLint uniColor = glGetUniformLocation(shaderProgram, "inColor");

    glUniformMatrix4fv(uniView, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(uniProj, 1, GL_FALSE, glm::value_ptr(proj));
    glUniformMatrix4fv(uniModel, 1, GL_FALSE, glm::value_ptr(model));
    glUniform1i(uniTexID, texID);
    glUniform3fv(uniColor, 1, glm::value_ptr(color));

    glDrawArrays(GL_TRIANGLES, start, verts);
}

void checkPickups(Camera& camera, MapLoader& map) {
    int gx = (int)(camera.x + 0.5f);
    int gz = (int)(camera.z + 0.5f);
    
    if (gx >= 0 && gx < map.mapW && gz >= 0 && gz < map.mapH) {
        char tile = map.mapData[gz][gx];
        if (tile >= 'a' && tile <= 'e') {
            keysCollected[tile - 'a'] = true;
            map.SetTile(gx, gz, '0');
        }
        if (tile == 'G') {
            printf("You Win!\n");
            exit(0);
        }
    }
}

void checkDoorInteractions(Camera& camera, MapLoader& map, AnimationSystem& anim, float dt) {
    int gx = (int)(camera.x + 0.5f);
    int gz = (int)(camera.z + 0.5f);
    
    int dx[] = {0, 0, 1, -1};
    int dz[] = {1, -1, 0, 0};
    
    for (int i = 0; i < 4; i++) {
        int nx = gx + dx[i];
        int nz = gz + dz[i];
        
        if (nx >= 0 && nx < map.mapW && nz >= 0 && nz < map.mapH) {
            char tile = map.mapData[nz][nx];
            if (tile >= 'A' && tile <= 'E') {
                if (keysCollected[tile - 'A']) {
                    anim.AddDoor(nx, nz);
                    keysCollected[tile - 'A'] = false;
                }
            }
        }
    }
    
    anim.Update(dt, map);
}

int main(int argc, char *argv[]){
    SDL_Init(SDL_INIT_VIDEO);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);
    SDL_Window* window = SDL_CreateWindow("Maze Game", screenWidth, screenHeight, SDL_WINDOW_OPENGL);
    SDL_GLContext context = SDL_GL_CreateContext(window);
    SDL_SetWindowRelativeMouseMode(window, true);
    gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress);
    
    std::vector<float> modelData;
    cubeVerts = loadModel("models/cube.txt", modelData);
    cubeStart = 0;
    knotVerts = loadModel("models/knot.txt", modelData);
    knotStart = cubeVerts;
    keyVerts = loadOBJ("models/key.obj", modelData);
    keyStart = knotStart + knotVerts;

    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);
    GLuint vbo;
    glGenBuffers(1, &vbo);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, modelData.size() * sizeof(float), modelData.data(), GL_STATIC_DRAW);

    shaderProgram = InitShader("textured-Vertex.glsl", "textured-Fragment.glsl");
    GLint posAttrib = glGetAttribLocation(shaderProgram, "position");
    glVertexAttribPointer(posAttrib, 3, GL_FLOAT, GL_FALSE, 8*sizeof(float), 0);
    glEnableVertexAttribArray(posAttrib);
    GLint normAttrib = glGetAttribLocation(shaderProgram, "inNormal");
    glVertexAttribPointer(normAttrib, 3, GL_FLOAT, GL_FALSE, 8*sizeof(float), (void*)(5*sizeof(float)));
    glEnableVertexAttribArray(normAttrib);
    GLint texAttrib = glGetAttribLocation(shaderProgram, "inTexcoord");
    glVertexAttribPointer(texAttrib, 2, GL_FLOAT, GL_FALSE, 8*sizeof(float), (void*)(3*sizeof(float)));
    glEnableVertexAttribArray(texAttrib);

    SDL_Surface* surface = SDL_LoadBMP("metal.bmp");
    if (!surface) { printf("Failed to load wood.bmp\n"); return 1; }
    glGenTextures(1, &tex0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, tex0);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface->w,surface->h, 0, GL_BGR,GL_UNSIGNED_BYTE,surface->pixels);
    glGenerateMipmap(GL_TEXTURE_2D);
    SDL_DestroySurface(surface);

    SDL_Surface* surface1 = SDL_LoadBMP("brick.bmp");
    if (!surface1) { printf("Failed to load brick.bmp\n"); return 1; }
    glGenTextures(1, &tex1);
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, tex1);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, surface1->w,surface1->h, 0, GL_BGR,GL_UNSIGNED_BYTE,surface1->pixels);
    glGenerateMipmap(GL_TEXTURE_2D);
    SDL_DestroySurface(surface1);

    glEnable(GL_DEPTH_TEST);

    MapLoader map;
    Camera camera;
    AnimationSystem animSystem;

    if (argc > 1) {
        map.Load(argv[1]);
    } else {
        map.Load("level1.txt");
    }
    
    camera.x = map.startX;
    camera.z = map.startZ;
    printf("Player Start: %f, %f\n", camera.x, camera.z);

    glUseProgram(shaderProgram);
    glUniform1i(glGetUniformLocation(shaderProgram, "tex0"), 0);
    glUniform1i(glGetUniformLocation(shaderProgram, "tex1"), 1);

    SDL_Event windowEvent;
    bool quit = false;
    const bool *keyState;
    
    float lastTime = SDL_GetTicks() / 1000.0f;

    while (!quit){
        float currentTime = SDL_GetTicks() / 1000.0f;
        float dt = currentTime - lastTime;
        lastTime = currentTime;

        while (SDL_PollEvent(&windowEvent)){
            if (windowEvent.type == SDL_EVENT_QUIT) quit = true;
            if (windowEvent.type == SDL_EVENT_KEY_UP && windowEvent.key.key == SDLK_ESCAPE) quit = true;
            if (windowEvent.type == SDL_EVENT_MOUSE_MOTION) {
                camera.dir += windowEvent.motion.xrel * 0.005f;
                camera.pitch -= windowEvent.motion.yrel * 0.005f;
                if (camera.pitch > 1.5f) camera.pitch = 1.5f;
                if (camera.pitch < -1.5f) camera.pitch = -1.5f;
            }
        }

        keyState = SDL_GetKeyboardState(NULL);
        
        float moveSpeed = 3.0f * dt;
        float nextX = camera.x;
        float nextZ = camera.z;
        
        if (keyState[SDL_SCANCODE_W]) {
            nextX += cos(camera.dir - 3.14159f/2.0f) * moveSpeed;
            nextZ += sin(camera.dir - 3.14159f/2.0f) * moveSpeed;
        }
        if (keyState[SDL_SCANCODE_S]) {
            nextX -= cos(camera.dir - 3.14159f/2.0f) * moveSpeed;
            nextZ -= sin(camera.dir - 3.14159f/2.0f) * moveSpeed;
        }
        if (keyState[SDL_SCANCODE_A]) {
            nextX -= cos(camera.dir) * moveSpeed;
            nextZ -= sin(camera.dir) * moveSpeed;
        }
        if (keyState[SDL_SCANCODE_D]) {
            nextX += cos(camera.dir) * moveSpeed;
            nextZ += sin(camera.dir) * moveSpeed;
        }

        if (keyState[SDL_SCANCODE_SPACE] && camera.y <= 0.001f) {
            camera.vy = 4.0f;
        }

        camera.Update(dt);

        if (map.IsWalkable(nextX, camera.z)) camera.x = nextX;
        if (map.IsWalkable(camera.x, nextZ)) camera.z = nextZ;
        
        checkPickups(camera, map);
        checkDoorInteractions(camera, map, animSystem, dt);

        glClearColor(0.2f, 0.4f, 0.8f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glm::mat4 view = camera.GetViewMatrix();
        glm::mat4 proj = glm::perspective(glm::radians(45.0f), screenWidth / (float) screenHeight, 0.1f, 100.0f);

        for (int z = 0; z < map.mapH; z++) {
            for (int x = 0; x < map.mapW; x++) {
                char tile = map.mapData[z][x];
                
                glm::mat4 model = glm::mat4(1.0f);
                model = glm::translate(model, glm::vec3(x, -0.5f, z));
                drawObject(view, proj, model, cubeStart, cubeVerts, 1, glm::vec3(0.4f, 0.4f, 0.4f));

                if (tile == 'W') {
                    model = glm::mat4(1.0f);
                    model = glm::translate(model, glm::vec3(x, 0.5f, z));
                    drawObject(view, proj, model, cubeStart, cubeVerts, 1, glm::vec3(1.0f, 1.0f, 1.0f));
                } else if (tile >= 'A' && tile <= 'E') {
                    float offsetY = animSystem.GetDoorOffset(x, z);
                
                    model = glm::mat4(1.0f);
                    model = glm::translate(model, glm::vec3(x, 0.5f + offsetY, z));
                    glm::vec3 color(1.0f, 1.0f, 1.0f);
                    if (tile == 'A') color = glm::vec3(1.0f, 0.0f, 0.0f);
                    if (tile == 'B') color = glm::vec3(0.0f, 1.0f, 0.0f);
                    if (tile == 'C') color = glm::vec3(0.0f, 0.0f, 1.0f);
                    if (tile == 'D') color = glm::vec3(1.0f, 1.0f, 0.0f);
                    if (tile == 'E') color = glm::vec3(1.0f, 0.0f, 1.0f);
                    drawObject(view, proj, model, cubeStart, cubeVerts, 0, color);
                } else if (tile >= 'a' && tile <= 'e') {
                    model = glm::mat4(1.0f);
                    model = glm::translate(model, glm::vec3(x, 0.3f, z));
                    model = glm::scale(model, glm::vec3(0.005f, 0.005f, 0.005f));
                    model = glm::rotate(model, (float)SDL_GetTicks()/1000.0f, glm::vec3(0,1,0));
                    glm::vec3 color(1.0f, 1.0f, 1.0f);
                    if (tile == 'a') color = glm::vec3(1.0f, 0.0f, 0.0f);
                    if (tile == 'b') color = glm::vec3(0.0f, 1.0f, 0.0f);
                    if (tile == 'c') color = glm::vec3(0.0f, 0.0f, 1.0f);
                    if (tile == 'd') color = glm::vec3(1.0f, 1.0f, 0.0f);
                    if (tile == 'e') color = glm::vec3(1.0f, 0.0f, 1.0f);
                    drawObject(view, proj, model, keyStart, keyVerts, -1, color);
                } else if (tile == 'G') {
                    model = glm::mat4(1.0f);
                    model = glm::translate(model, glm::vec3(x, 0.3f, z));
                    model = glm::scale(model, glm::vec3(0.3f, 0.3f, 0.3f));
                    model = glm::rotate(model, (float)SDL_GetTicks()/1000.0f, glm::vec3(1,0,0));
                    model = glm::rotate(model, (float)SDL_GetTicks()/1000.0f, glm::vec3(0,1,0));
                    model = glm::rotate(model, (float)SDL_GetTicks()/1000.0f, glm::vec3(0,0,1));
                    glm::vec3 color(1.0f,215.0f/255, 0.0f);
                    drawObject(view, proj, model, knotStart, knotVerts, -1, color);
                }
            }
        }
        
        glClear(GL_DEPTH_BUFFER_BIT);
        for(int i=0; i<5; i++){
            if(keysCollected[i]){
                 glm::mat4 model = glm::inverse(view);
                 model = glm::translate(model, glm::vec3(-0.5f + (i * 0.05f), -0.3f, -1.0f));
                 model = glm::scale(model, glm::vec3(0.001f, 0.001f, 0.001f));
                 model = glm::rotate(model, (float)SDL_GetTicks()/1000.0f, glm::vec3(0,1,0));
                 glm::vec3 color(1.0f, 1.0f, 1.0f);
                 if (i == 0) color = glm::vec3(1.0f, 0.0f, 0.0f);
                 if (i == 1) color = glm::vec3(0.0f, 1.0f, 0.0f);
                 if (i == 2) color = glm::vec3(0.0f, 0.0f, 1.0f);
                 if (i == 3) color = glm::vec3(1.0f, 1.0f, 0.0f);
                 if (i == 4) color = glm::vec3(1.0f, 0.0f, 1.0f);
                 drawObject(view, proj, model, keyStart, keyVerts, -1, color);
            }
        }

        SDL_GL_SwapWindow(window);
    }
    
    glDeleteProgram(shaderProgram);
    glDeleteBuffers(1, &vbo);
    glDeleteVertexArrays(1, &vao);
    SDL_GL_DestroyContext(context);
    SDL_Quit();
    return 0;
}
