#ifndef CAMERA_H
#define CAMERA_H

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"

class Camera {
public:
    float x, y, z;
    float dir;   // Yaw
    float pitch;
    float vy;    // Vertical velocity

    Camera();
    void Update(float dt);
    glm::mat4 GetViewMatrix();
    glm::vec3 GetPos();
    glm::vec3 GetDirVector();
};

#endif
