#include "AnimationSystem.h"

void AnimationSystem::Update(float dt, MapLoader& map) {
    for (auto it = activeDoors.begin(); it != activeDoors.end(); ) {
        it->offsetY -= 1.0f * dt;
        it->timer -= dt;
        
        if (it->timer <= 0) {
            map.SetTile(it->x, it->z, '0');
            it = activeDoors.erase(it);
        } else {
            ++it;
        }
    }
}

void AnimationSystem::AddDoor(int x, int z) {
    for (const auto& door : activeDoors) {
        if (door.x == x && door.z == z) {
            return;
        }
    }
    activeDoors.push_back({x, z, 0.0f, 1.0f});
}

float AnimationSystem::GetDoorOffset(int x, int z) {
    for (const auto& door : activeDoors) {
        if (door.x == x && door.z == z) {
            return door.offsetY;
        }
    }
    return 0.0f;
}
