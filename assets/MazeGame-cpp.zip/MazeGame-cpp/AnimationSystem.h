#ifndef ANIMATIONSYSTEM_H
#define ANIMATIONSYSTEM_H

#include <vector>
#include "MapLoader.h"

struct DoorAnimation {
    int x, z;
    float offsetY;
    float timer;
};

class AnimationSystem {
public:
    std::vector<DoorAnimation> activeDoors;

    void Update(float dt, MapLoader& map);
    void AddDoor(int x, int z);
    float GetDoorOffset(int x, int z);
};

#endif
