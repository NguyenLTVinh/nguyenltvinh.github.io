#include "Camera.h"
#include <cmath>

Camera::Camera() : x(0), y(0), z(0), dir(0), pitch(0), vy(0) {}

void Camera::Update(float dt) {
    vy -= 9.8f * dt;
    y += vy * dt;
    if (y < 0.0f) {
        y = 0.0f;
        vy = 0.0f;
    }
}

glm::mat4 Camera::GetViewMatrix() {
    glm::vec3 camPos(x, 0.5f + y, z);
    glm::vec3 camDir = GetDirVector();
    return glm::lookAt(camPos, camPos + camDir, glm::vec3(0.0f, 1.0f, 0.0f));
}

glm::vec3 Camera::GetPos() {
    return glm::vec3(x, 0.5f + y, z);
}

glm::vec3 Camera::GetDirVector() {
    return glm::vec3(
        cos(pitch) * cos(dir - 3.14159f/2.0f),
        sin(pitch),
        cos(pitch) * sin(dir - 3.14159f/2.0f)
    );
}
