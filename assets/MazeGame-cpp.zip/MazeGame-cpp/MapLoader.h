#ifndef MAPLOADER_H
#define MAPLOADER_H

#include <vector>
#include <string>

class MapLoader {
public:
    std::vector<std::string> mapData;
    int mapW, mapH;
    float startX, startZ;

    MapLoader();
    void Load(const char* filename);
    char GetTile(int x, int z);
    void SetTile(int x, int z, char type);
    bool IsWalkable(float x, float z);
    bool CheckTile(float x, float z);
};

#endif
