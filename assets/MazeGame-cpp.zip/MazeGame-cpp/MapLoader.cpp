#include "MapLoader.h"
#include <fstream>
#include <iostream>
#include <cstdio>

MapLoader::MapLoader() : mapW(0), mapH(0), startX(0), startZ(0) {}

void MapLoader::Load(const char* filename) {
    std::ifstream file(filename);
    if (file.is_open()) {
        int w, h;
        file >> w >> h;
        mapW = w + 2;
        mapH = h + 2;
        printf("Map loaded: %s (%dx%d) -> Padded to (%dx%d)\n", filename, w, h, mapW, mapH);
        
        std::string topBottomRow(mapW, 'W');
        mapData.push_back(topBottomRow);

        std::string line;
        std::getline(file, line); // consume newline
        for (int i = 0; i < h; i++) {
            std::getline(file, line);
            // Handle potential Carriage Return on Linux/Mac reading Windows files
            if (!line.empty() && line[line.length()-1] == '\r') {
                line.erase(line.length()-1);
            }
            // Truncate if longer than expected width
            if (line.length() > w) {
                line = line.substr(0, w);
            }
            
            std::string paddedLine = "W" + line + "W";
            if (paddedLine.length() < mapW) paddedLine.append(mapW - paddedLine.length(), 'W');
            
            mapData.push_back(paddedLine);
            for (int j = 0; j < (int)line.length(); j++) {
                if (line[j] == 'S') {
                    startX = j + 1;
                    startZ = i + 1;
                }
            }
        }
        mapData.push_back(topBottomRow);
        
        file.close();
    } else {
        printf("Failed to load map: %s\n", filename);
    }
}

char MapLoader::GetTile(int x, int z) {
    if (x >= 0 && x < mapW && z >= 0 && z < mapH) {
        return mapData[z][x];
    }
    return 'W';
}

void MapLoader::SetTile(int x, int z, char type) {
    if (x >= 0 && x < mapW && z >= 0 && z < mapH) {
        mapData[z][x] = type;
    }
}

bool MapLoader::CheckTile(float x, float z) {
    int gx = (int)(x + 0.5f);
    int gz = (int)(z + 0.5f);
    
    if (gx < 0 || gx >= mapW || gz < 0 || gz >= mapH) return false;
    
    char tile = mapData[gz][gx];
    if (tile == 'W') return false;
    if (tile >= 'A' && tile <= 'E') {
        return false;
    }
    return true;
}

bool MapLoader::IsWalkable(float x, float z) {
    float r = 0.2f;
    if (!CheckTile(x + r, z + r)) return false;
    if (!CheckTile(x - r, z + r)) return false;
    if (!CheckTile(x + r, z - r)) return false;
    if (!CheckTile(x - r, z - r)) return false;
    return true;
}
