#ifndef PARSE_PGA_H
#define PARSE_PGA_H

#include "PGA_3D.h"
#include "image_lib.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct Material {
  float ar, ag, ab;
  float dr, dg, db;
  float sr, sg, sb;
  float ns;
  float tr, tg, tb;
  float ior;
  Material(float ar_ = 0, float ag_ = 0, float ab_ = 0, float dr_ = 1,
           float dg_ = 1, float db_ = 1, float sr_ = 0, float sg_ = 0,
           float sb_ = 0, float ns_ = 5, float tr_ = 0, float tg_ = 0,
           float tb_ = 0, float ior_ = 1)
      : ar(ar_), ag(ag_), ab(ab_), dr(dr_), dg(dg_), db(db_), sr(sr_), sg(sg_),
        sb(sb_), ns(ns_), tr(tr_), tg(tg_), tb(tb_), ior(ior_) {}
};

struct Sphere {
  Point3D center;
  float radius;
  Material mat;
};

struct Triangle {
  Point3D v0, v1, v2;
  Dir3D normal;
  bool useVertexNormals;
  Dir3D n0, n1, n2;
  Material mat;
};

struct Plane {
  Point3D point;
  Dir3D normal;
  Material mat;
};

struct Cylinder {
  Point3D base;
  Dir3D axis;
  float radius;
  float height;
  Material mat;
};

struct Cone {
  Point3D apex;
  Dir3D axis;
  float angle;
  float height;
  Material mat;
};

struct Box {
  Point3D minCorner;
  Point3D maxCorner;
  Material mat;
};

enum LightType { POINT_LIGHT, DIRECTIONAL_LIGHT, SPOT_LIGHT };

struct Light {
  LightType type;
  Color intensity;
  Point3D pos;
  Dir3D dir;
  float angle1;
  float angle2;
  Light(LightType t = POINT_LIGHT, Color c = Color(1, 1, 1))
      : type(t), intensity(c), pos(0, 0, 0), dir(0, 0, 0), angle1(0),
        angle2(0) {}
};

// Defaults
int img_width = 800, img_height = 600;
std::string imgName = "raytraced.png";

Point3D eye = Point3D(0, 0, 0);
Dir3D forward = Dir3D(0, 0, -1).normalized();
Dir3D up = Dir3D(0, 1, 0).normalized();
Dir3D right = Dir3D(-1, 0, 0).normalized();
float halfAngleVFOV = 35.0f;

std::vector<Sphere> spheres;
std::vector<Light> lights;
std::vector<Triangle> triangles;
std::vector<Plane> planes;
std::vector<Box> boxes;
std::vector<Cylinder> cylinders;
std::vector<Cone> cones;

Point3D *vertices = nullptr;
Dir3D *normals = nullptr;
int max_vertices_count = 0;
int max_normals_count = 0;
int current_vertex_index = 0;
int current_normal_index = 0;

Color ambient_light = Color(0, 0, 0);
Color background_color = Color(0, 0, 0);
int max_depth = 5;

void parseSceneFile(std::string fileName) {
  std::ifstream in(fileName);
  if (!in) {
    std::cerr << "Error opening scene file: " << fileName << std::endl;
    exit(1);
  }

  std::string line;
  Material currentMat(0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 0, 0, 0,
                      1); // default

  while (std::getline(in, line)) {
    if (line.empty())
      continue;

    size_t firstNon = line.find_first_not_of(" \t");
    if (firstNon == std::string::npos)
      continue;
    if (line[firstNon] == '#')
      continue;

    std::istringstream iss(line);
    std::string cmd;
    iss >> cmd;

    if (cmd == "film_resolution:") {
      iss >> img_width >> img_height;
    } else if (cmd == "output_image:") {
      iss >> imgName;
    } else if (cmd == "camera_pos:") {
      float x, y, z;
      iss >> x >> y >> z;
      eye = Point3D(x, y, z);
    } else if (cmd == "camera_fwd:") {
      float x, y, z;
      iss >> x >> y >> z;
      forward = Dir3D(x, y, z).normalized();
    } else if (cmd == "camera_up:") {
      float x, y, z;
      iss >> x >> y >> z;
      up = Dir3D(x, y, z).normalized();
    } else if (cmd == "camera_fov_ha:") {
      iss >> halfAngleVFOV;
    } else if (cmd == "sphere:") {
      float x, y, z, r;
      if (iss >> x >> y >> z >> r) {
        Sphere s;
        s.center = Point3D(x, y, z);
        s.radius = r;
        s.mat = currentMat;
        spheres.push_back(s);
      }
    } else if (cmd == "material:") {
      // ar ag ab dr dg db sr sg sb ns tr tg tb ior
      float ar, ag, ab, dr, dg, db, sr, sg, sb, ns, tr, tg, tb, ior;
      if (iss >> ar >> ag >> ab >> dr >> dg >> db >> sr >> sg >> sb >> ns >>
          tr >> tg >> tb >> ior) {
        currentMat =
            Material(ar, ag, ab, dr, dg, db, sr, sg, sb, ns, tr, tg, tb, ior);
      } else {
        std::cerr << "Warning: malformed material line: " << line << std::endl;
      }
    } else if (cmd == "ambient_light:") {
      float r, g, b;
      iss >> r >> g >> b;
      ambient_light = Color(r, g, b);
    } else if (cmd == "background:") {
      float r, g, b;
      iss >> r >> g >> b;
      background_color = Color(r, g, b);
    } else if (cmd == "point_light:") {
      float r, g, b, x, y, z;
      if (iss >> r >> g >> b >> x >> y >> z) {
        Light L(POINT_LIGHT, Color(r, g, b));
        L.pos = Point3D(x, y, z);
        lights.push_back(L);
      }
    } else if (cmd == "directional_light:") {
      float r, g, b, x, y, z;
      if (iss >> r >> g >> b >> x >> y >> z) {
        Light L(DIRECTIONAL_LIGHT, Color(r, g, b));
        L.dir = Dir3D(x, y, z).normalized();
        lights.push_back(L);
      }
    } else if (cmd == "spot_light:") {
      // r g b px py pz dx dy dz angle1 angle2
      float r, g, b, px, py, pz, dx, dy, dz, a1, a2;
      if (iss >> r >> g >> b >> px >> py >> pz >> dx >> dy >> dz >> a1 >> a2) {
        Light L(SPOT_LIGHT, Color(r, g, b));
        L.pos = Point3D(px, py, pz);
        L.dir = Dir3D(dx, dy, dz).normalized();
        L.angle1 = a1;
        L.angle2 = a2;
        lights.push_back(L);
      }
    } else if (cmd == "max_depth:") {
      iss >> max_depth;
      if (max_depth < 0)
        max_depth = 0;
    } else if (cmd == "max_vertices:") {
      int n;
      if (iss >> n) {
        max_vertices_count = n;
        vertices = new Point3D[n];
        current_vertex_index = 0;
      }
    } else if (cmd == "max_normals:") {
      int n;
      if (iss >> n) {
        max_normals_count = n;
        normals = new Dir3D[n];
        current_normal_index = 0;
      }
    } else if (cmd == "vertex:") {
      if (vertices == nullptr) {
        std::cerr << "Error: vertex specified before max_vertices" << std::endl;
        exit(1);
      }
      float x, y, z;
      if (iss >> x >> y >> z) {
        if (current_vertex_index >= max_vertices_count) {
          std::cerr << "Error: more vertices than max_vertices allows"
                    << std::endl;
          exit(1);
        }
        vertices[current_vertex_index++] = Point3D(x, y, z);
      }
    } else if (cmd == "normal:") {
      if (normals == nullptr) {
        std::cerr << "Error: normal specified before max_normals" << std::endl;
        exit(1);
      }
      float x, y, z;
      if (iss >> x >> y >> z) {
        if (current_normal_index >= max_normals_count) {
          std::cerr << "Error: more normals than max_normals allows"
                    << std::endl;
          exit(1);
        }
        normals[current_normal_index++] = Dir3D(x, y, z).normalized();
      }
    } else if (cmd == "triangle:") {
      int i0, i1, i2;
      if (iss >> i0 >> i1 >> i2) {
        Triangle tri;
        tri.v0 = vertices[i0];
        tri.v1 = vertices[i1];
        tri.v2 = vertices[i2];
        // Compute flat normal using cross product
        Dir3D edge1 = tri.v1 - tri.v0;
        Dir3D edge2 = tri.v2 - tri.v0;
        tri.normal = cross(edge1, edge2).normalized();
        tri.useVertexNormals = false;
        tri.mat = currentMat;
        triangles.push_back(tri);
      }
    } else if (cmd == "normal_triangle:") {
      int i0, i1, i2, n0, n1, n2;
      if (iss >> i0 >> i1 >> i2 >> n0 >> n1 >> n2) {
        Triangle tri;
        tri.v0 = vertices[i0];
        tri.v1 = vertices[i1];
        tri.v2 = vertices[i2];
        tri.n0 = normals[n0];
        tri.n1 = normals[n1];
        tri.n2 = normals[n2];
        tri.useVertexNormals = true;
        tri.mat = currentMat;
        triangles.push_back(tri);
      }
    } else if (cmd == "plane:") {
      float px, py, pz, nx, ny, nz;
      if (iss >> px >> py >> pz >> nx >> ny >> nz) {
        Plane pl;
        pl.point = Point3D(px, py, pz);
        pl.normal = Dir3D(nx, ny, nz).normalized();
        pl.mat = currentMat;
        planes.push_back(pl);
      }
    } else if (cmd == "box:") {
      float xmin, ymin, zmin, xmax, ymax, zmax;
      if (iss >> xmin >> ymin >> zmin >> xmax >> ymax >> zmax) {
        Box b;
        b.minCorner = Point3D(xmin, ymin, zmin);
        b.maxCorner = Point3D(xmax, ymax, zmax);
        b.mat = currentMat;
        boxes.push_back(b);
      }
    } else if (cmd == "cylinder:") {
      float bx, by, bz, ax, ay, az, radius, height;
      if (iss >> bx >> by >> bz >> ax >> ay >> az >> radius >> height) {
        Cylinder c;
        c.base = Point3D(bx, by, bz);
        c.axis = Dir3D(ax, ay, az).normalized();
        c.radius = radius;
        c.height = height;
        c.mat = currentMat;
        cylinders.push_back(c);
      }
    } else if (cmd == "cone:") {
      float apexx, apexy, apexz, ax, ay, az, angleDeg, height;
      if (iss >> apexx >> apexy >> apexz >> ax >> ay >> az >> angleDeg >>
          height) {
        Cone c;
        c.apex = Point3D(apexx, apexy, apexz);
        c.axis = Dir3D(ax, ay, az).normalized();
        c.angle = angleDeg * (M_PI / 180.0f);
        c.height = height;
        c.mat = currentMat;
        cones.push_back(c);
      }
    }
  }

  for (auto &tri : triangles) {
    if (tri.useVertexNormals) {
      tri.n0 = tri.n0.normalized();
      tri.n1 = tri.n1.normalized();
      tri.n2 = tri.n2.normalized();
    } else {
      tri.normal = tri.normal.normalized();
    }
  }

  forward = forward.normalized();
  right = cross(up, forward).normalized();
  up = cross(forward, right).normalized();

  std::cout << "Scene parsed. Spheres: " << spheres.size()
            << ", Lights: " << lights.size() << ", ambient: ("
            << ambient_light.r << "," << ambient_light.g << ","
            << ambient_light.b << ")"
            << ", background: (" << background_color.r << ","
            << background_color.g << "," << background_color.b << ")\n";
}

#endif
