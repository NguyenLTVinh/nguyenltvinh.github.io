// To Compile: g++ -fsanitize=address -std=c++11 rayTrace_pga.cpp

// For Visual Studios
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS // For fopen and sscanf
#define _USE_MATH_DEFINES
#endif

// Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION       // only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION // only place once in one .cpp files
#include "image_lib.h" //Defines an image class and a color class

// #3D PGA
#include "PGA_3D.h"

// High resolution timer
#include <chrono>

// Multi threading
#include <omp.h>

// Scene file parser
#include "parse_pga.h"

// Small offset
const float EPSILON = 1e-3f;

// C++11 does not have built in clamp in std so this goes here.
template <typename T> T clamp(T val, T minVal, T maxVal) {
  return (val < minVal) ? minVal : (val > maxVal ? maxVal : val);
}

enum PrimitiveType {
  SPHERE_TYPE,
  TRIANGLE_TYPE,
  PLANE_TYPE,
  BOX_TYPE,
  CYLINDER_TYPE,
  CONE_TYPE
};

struct HitResult {
  bool hit = false;
  PrimitiveType type;
  int index = -1;
  float t = -1.0f;
  Point3D hitPoint;
  Dir3D normal;
  Material *mat = nullptr;
  float u = 0.0f, v = 0.0f;
  bool hitCap = false;
  bool hitTop = false;
};

float intersectSphere(Point3D &rayOrigin, Dir3D &rayDir, Point3D &center,
                      float radius) {
  Dir3D L = Dir3D(rayOrigin.x - center.x, rayOrigin.y - center.y,
                  rayOrigin.z - center.z);
  // O + t * D
  float a = dot(rayDir, rayDir);
  float b = 2.0f * dot(rayDir, L);
  float c = dot(L, L) - radius * radius;
  float discr = b * b - 4 * a * c;
  if (discr < 0.0f)
    return -1.0f;
  float sqrtD = sqrtf(discr);
  float t0 = (-b - sqrtD) / (2.0f * a);
  float t1 = (-b + sqrtD) / (2.0f * a);
  // smallest positive t
  float t = -1.0f;
  if (t0 > EPSILON)
    t = t0;
  else if (t1 > EPSILON)
    t = t1;
  return t;
}

float intersectTriangle(Point3D &rayOrigin, Dir3D &rayDir, Triangle &tri,
                        float &outU, float &outV) {
  Dir3D edge1 = tri.v1 - tri.v0;
  Dir3D edge2 = tri.v2 - tri.v0;
  Dir3D h = cross(rayDir, edge2);
  float a = dot(edge1, h);

  if (fabs(a) < EPSILON)
    return -1.0f;

  float f = 1.0f / a;
  Dir3D s = rayOrigin - tri.v0;
  float u = f * dot(s, h);

  if (u < 0.0f || u > 1.0f)
    return -1.0f;

  Dir3D q = cross(s, edge1);
  float v = f * dot(rayDir, q);

  if (v < 0.0f || u + v > 1.0f)
    return -1.0f;

  float t = f * dot(edge2, q);
  outU = u;
  outV = v;

  return (t > EPSILON) ? t : -1.0f;
}

float intersectPlane(Point3D &rayOrigin, Dir3D &rayDir, Plane &pl) {
  float denom = dot(pl.normal, rayDir);
  if (fabs(denom) < EPSILON)
    return -1.0f;
  float t = dot(pl.point - rayOrigin, pl.normal) / denom;
  return (t > EPSILON) ? t : -1.0f;
}

float intersectBox(Point3D &rayOrigin, Dir3D &rayDir, Box &b) {
  float tmin = (b.minCorner.x - rayOrigin.x) / rayDir.x;
  float tmax = (b.maxCorner.x - rayOrigin.x) / rayDir.x;
  if (tmin > tmax)
    std::swap(tmin, tmax);

  float tymin = (b.minCorner.y - rayOrigin.y) / rayDir.y;
  float tymax = (b.maxCorner.y - rayOrigin.y) / rayDir.y;
  if (tymin > tymax)
    std::swap(tymin, tymax);

  if ((tmin > tymax) || (tymin > tmax))
    return -1.0f;

  if (tymin > tmin)
    tmin = tymin;
  if (tymax < tmax)
    tmax = tymax;

  float tzmin = (b.minCorner.z - rayOrigin.z) / rayDir.z;
  float tzmax = (b.maxCorner.z - rayOrigin.z) / rayDir.z;
  if (tzmin > tzmax)
    std::swap(tzmin, tzmax);

  if ((tmin > tzmax) || (tzmin > tmax))
    return -1.0f;

  if (tzmin > tmin)
    tmin = tzmin;
  if (tzmax < tmax)
    tmax = tzmax;

  return (tmin > EPSILON) ? tmin : ((tmax > EPSILON) ? tmax : -1.0f);
}

float intersectCylinder(Point3D &rayOrigin, Dir3D &rayDir, Cylinder &cyl,
                        bool &hitCap, bool &hitTop) {
  hitCap = false;
  hitTop = false;
  float bestT = -1.0f;

  // Intersect infinite cylinder (side surface)
  Dir3D d = rayDir - dot(rayDir, cyl.axis) * cyl.axis;
  Dir3D delta = rayOrigin - cyl.base;
  Dir3D deltaProj = delta - dot(delta, cyl.axis) * cyl.axis;

  float a = dot(d, d);
  float b = 2.0f * dot(d, deltaProj);
  float c = dot(deltaProj, deltaProj) - cyl.radius * cyl.radius;

  float discr = b * b - 4 * a * c;
  if (discr >= 0 && a > EPSILON) {
    float sqrtD = sqrtf(discr);
    float t0 = (-b - sqrtD) / (2 * a);
    float t1 = (-b + sqrtD) / (2 * a);

    for (float t : {t0, t1}) {
      if (t < EPSILON)
        continue;
      float y = dot(cyl.axis, (rayOrigin + rayDir * t) - cyl.base);
      if (y >= 0 && y <= cyl.height) {
        if (bestT < 0 || t < bestT) {
          bestT = t;
        }
      }
    }
  }

  // Intersect bottom cap (disk at base)
  float denom = dot(cyl.axis, rayDir);
  if (fabs(denom) > EPSILON) {
    float t = dot(cyl.base - rayOrigin, cyl.axis) / denom;
    if (t > EPSILON) {
      Point3D p = rayOrigin + rayDir * t;
      Dir3D toP = p - cyl.base;
      float distSq = dot(toP, toP) - dot(toP, cyl.axis) * dot(toP, cyl.axis);
      if (distSq <= cyl.radius * cyl.radius) {
        if (bestT < 0 || t < bestT) {
          bestT = t;
          hitCap = true;
          hitTop = false;
        }
      }
    }
  }

  // Intersect top cap (disk at base + height * axis)
  Point3D topCenter = cyl.base + cyl.axis * cyl.height;
  if (fabs(denom) > EPSILON) {
    float t = dot(topCenter - rayOrigin, cyl.axis) / denom;
    if (t > EPSILON) {
      Point3D p = rayOrigin + rayDir * t;
      Dir3D toP = p - topCenter;
      float distSq = dot(toP, toP) - dot(toP, cyl.axis) * dot(toP, cyl.axis);
      if (distSq <= cyl.radius * cyl.radius) {
        if (bestT < 0 || t < bestT) {
          bestT = t;
          hitCap = true;
          hitTop = true;
        }
      }
    }
  }

  return bestT;
}

float intersectCone(Point3D &rayOrigin, Dir3D &rayDir, Cone &cone,
                    bool &hitBase) {
  hitBase = false;
  float bestT = -1.0f;

  // Intersect infinite double cone
  Dir3D co = rayOrigin - cone.apex;
  float cos2 = cosf(cone.angle) * cosf(cone.angle);

  float dv = dot(rayDir, cone.axis);
  float coV = dot(co, cone.axis);

  float a = dv * dv - cos2;
  float b = 2 * (dv * coV - dot(rayDir, co) * cos2);
  float c = coV * coV - dot(co, co) * cos2;

  float discr = b * b - 4 * a * c;
  if (discr >= 0 && fabs(a) > EPSILON) {
    float sqrtD = sqrtf(discr);
    float t0 = (-b - sqrtD) / (2 * a);
    float t1 = (-b + sqrtD) / (2 * a);

    for (float t : {t0, t1}) {
      if (t < EPSILON)
        continue;
      Point3D hitPt = rayOrigin + rayDir * t;
      float y = dot(cone.axis, hitPt - cone.apex);
      // Only consider hits in the positive direction along axis, within height
      if (y >= 0 && y <= cone.height) {
        if (bestT < 0 || t < bestT) {
          bestT = t;
        }
      }
    }
  }

  // Intersect base cap (disk at apex + height * axis)
  Point3D baseCenter = cone.apex + cone.axis * cone.height;
  float baseRadius = cone.height * tanf(cone.angle);

  float denom = dot(cone.axis, rayDir);
  if (fabs(denom) > EPSILON) {
    float t = dot(baseCenter - rayOrigin, cone.axis) / denom;
    if (t > EPSILON) {
      Point3D p = rayOrigin + rayDir * t;
      Dir3D toP = p - baseCenter;
      float distSq = dot(toP, toP) - dot(toP, cone.axis) * dot(toP, cone.axis);
      if (distSq <= baseRadius * baseRadius) {
        if (bestT < 0 || t < bestT) {
          bestT = t;
          hitBase = true;
        }
      }
    }
  }

  return bestT;
}

HitResult findIntersection(Point3D &rayOrigin, Dir3D &rayDir) {
  HitResult result;
  result.t = 1e30f;

  // Check spheres
  for (size_t i = 0; i < spheres.size(); ++i) {
    float t = intersectSphere(rayOrigin, rayDir, spheres[i].center,
                              spheres[i].radius);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = SPHERE_TYPE;
    }
  }

  // Check triangles
  for (size_t i = 0; i < triangles.size(); ++i) {
    float u, v;
    float t = intersectTriangle(rayOrigin, rayDir, triangles[i], u, v);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = TRIANGLE_TYPE;
      result.u = u;
      result.v = v;
    }
  }

  // Check planes
  for (size_t i = 0; i < planes.size(); ++i) {
    float t = intersectPlane(rayOrigin, rayDir, planes[i]);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = PLANE_TYPE;
    }
  }

  // Check boxes
  for (size_t i = 0; i < boxes.size(); ++i) {
    float t = intersectBox(rayOrigin, rayDir, boxes[i]);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = BOX_TYPE;
    }
  }

  // Check cylinders (with cap info)
  for (size_t i = 0; i < cylinders.size(); ++i) {
    bool hitCap, hitTop;
    float t =
        intersectCylinder(rayOrigin, rayDir, cylinders[i], hitCap, hitTop);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = CYLINDER_TYPE;
      result.hitCap = hitCap;
      result.hitTop = hitTop;
    }
  }

  // Check cones (with cap info)
  for (size_t i = 0; i < cones.size(); ++i) {
    bool hitBase;
    float t = intersectCone(rayOrigin, rayDir, cones[i], hitBase);
    if (t > 0.0f && t < result.t) {
      result.hit = true;
      result.t = t;
      result.index = (int)i;
      result.type = CONE_TYPE;
      result.hitCap = hitBase;
    }
  }

  if (!result.hit)
    return result;

  // Calculate hit point
  result.hitPoint = Point3D(rayOrigin.x + rayDir.x * result.t,
                            rayOrigin.y + rayDir.y * result.t,
                            rayOrigin.z + rayDir.z * result.t);

  // Calculate normal and material based on type
  switch (result.type) {
  case SPHERE_TYPE: {
    Sphere &s = spheres[result.index];
    result.normal = (result.hitPoint - s.center).normalized();
    result.mat = &s.mat;
    break;
  }
  case TRIANGLE_TYPE: {
    Triangle &tri = triangles[result.index];
    if (tri.useVertexNormals) {
      float w = 1.0f - result.u - result.v;
      result.normal =
          (w * tri.n0 + result.u * tri.n1 + result.v * tri.n2).normalized();
    } else {
      result.normal = tri.normal;
    }
    result.mat = &tri.mat;
    break;
  }
  case PLANE_TYPE: {
    Plane &pl = planes[result.index];
    result.normal = pl.normal;
    result.mat = &pl.mat;
    break;
  }
  case BOX_TYPE: {
    Box &b = boxes[result.index];
    const float eps = 1e-4f;
    if (fabs(result.hitPoint.x - b.minCorner.x) < eps)
      result.normal = Dir3D(-1, 0, 0);
    else if (fabs(result.hitPoint.x - b.maxCorner.x) < eps)
      result.normal = Dir3D(1, 0, 0);
    else if (fabs(result.hitPoint.y - b.minCorner.y) < eps)
      result.normal = Dir3D(0, -1, 0);
    else if (fabs(result.hitPoint.y - b.maxCorner.y) < eps)
      result.normal = Dir3D(0, 1, 0);
    else if (fabs(result.hitPoint.z - b.minCorner.z) < eps)
      result.normal = Dir3D(0, 0, -1);
    else
      result.normal = Dir3D(0, 0, 1);
    result.mat = &b.mat;
    break;
  }
  case CYLINDER_TYPE: {
    Cylinder &cyl = cylinders[result.index];
    if (result.hitCap) {
      // Hit one of the caps - normal is along axis
      result.normal = result.hitTop ? cyl.axis : (cyl.axis * -1.0f);
    } else {
      // Hit the side - normal is perpendicular to axis
      Dir3D toHit = result.hitPoint - cyl.base;
      float proj = dot(toHit, cyl.axis);
      Point3D axisPoint = cyl.base + cyl.axis * proj;
      result.normal = (result.hitPoint - axisPoint).normalized();
    }
    result.mat = &cyl.mat;
    break;
  }
  case CONE_TYPE: {
    Cone &cone = cones[result.index];
    if (result.hitCap) {
      // Hit the base - normal points away from apex along axis
      result.normal = cone.axis;
    } else {
      // Hit the side - compute surface normal
      Dir3D toHit = result.hitPoint - cone.apex;
      float proj = dot(toHit, cone.axis);
      Point3D axisPoint = cone.apex + cone.axis * proj;
      Dir3D radialDir = (result.hitPoint - axisPoint).normalized();
      float sinAngle = sinf(cone.angle);
      float cosAngle = cosf(cone.angle);
      // Surface normal for cone: perpendicular to surface
      result.normal =
          (radialDir * cosAngle - cone.axis * sinAngle).normalized();
    }
    result.mat = &cone.mat;
    break;
  }
  }

  return result;
}

bool isShadowBlocked(Point3D &origin, Dir3D &dir, float maxDist) {
  // Check spheres
  for (Sphere &s : spheres) {
    float t = intersectSphere(origin, dir, s.center, s.radius);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  // Check triangles
  for (Triangle &tri : triangles) {
    float u, v;
    float t = intersectTriangle(origin, dir, tri, u, v);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  // Check planes
  for (Plane &pl : planes) {
    float t = intersectPlane(origin, dir, pl);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  // Check boxes
  for (Box &b : boxes) {
    float t = intersectBox(origin, dir, b);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  // Check cylinders
  for (Cylinder &cyl : cylinders) {
    bool hitCap, hitTop;
    float t = intersectCylinder(origin, dir, cyl, hitCap, hitTop);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  // Check cones
  for (Cone &cone : cones) {
    bool hitBase;
    float t = intersectCone(origin, dir, cone, hitBase);
    if (t > 0.0f && t < maxDist - EPSILON)
      return true;
  }

  return false;
}

Dir3D reflect(Dir3D &I, Dir3D &N) {
  float dotIN = dot(I, N);
  Dir3D R = I - (2.0f * dotIN) * N;
  return R.normalized();
}

Dir3D refract(Dir3D &I, Dir3D &N, float ior) {
  Dir3D I_norm = I.normalized();
  float cosi = clamp(dot(I_norm, N), -1.0f, 1.0f);
  float nui = 1, nur = ior;
  Dir3D n = N;

  if (cosi < 0) {
    cosi = -cosi;
  } else {
    std::swap(nui, nur);
    n = N * -1.0f;
  }

  float nu = nui / nur;
  float k = 1 - nu * nu * (1 - cosi * cosi);
  if (k < 0)
    return Dir3D(0, 0, 0);

  return (nu * I_norm + (nu * cosi - sqrtf(k)) * n).normalized();
}

Color ambient(Material &m, float scale) {
  return Color(ambient_light.r * m.ar * scale, ambient_light.g * m.ag * scale,
               ambient_light.b * m.ab * scale);
}

Color diffuseContribution(Light &L, Dir3D &N, Material &m, Dir3D &Ldir) {
  float NdotL = std::max(dot(N, Ldir), 0.0f);
  return Color(m.dr * NdotL * L.intensity.r, m.dg * NdotL * L.intensity.g,
               m.db * NdotL * L.intensity.b);
}

Color specularContribution(Light &L, Dir3D &N, Dir3D &V, Material &m,
                           Dir3D &Ldir) {
  Dir3D negLdir = Ldir * -1.0f;
  Dir3D R = reflect(negLdir, N);
  float RdotV = dot(R, V);
  RdotV = clamp(RdotV, 0.0f, 1.0f);
  float specFactor = (m.ns > 0.0f) ? powf(RdotV, m.ns) : 0.0f;
  return Color(m.sr * specFactor * L.intensity.r,
               m.sg * specFactor * L.intensity.g,
               m.sb * specFactor * L.intensity.b);
}

Color evaluateRayTree(Point3D &origin, Dir3D &rayDir, int depth);

Color applyLightingModel(Point3D &origin, Dir3D &rayDir, int depth,
                         Point3D &hitPoint, Dir3D &N, Material &m) {
  Color contribution(0.0f, 0.0f, 0.0f);
  Dir3D V = (origin - hitPoint).normalized();

  for (Light &L : lights) {
    Dir3D Ldir;
    float attenuation = 1.0f;
    float maxLightDist = 1e30f;

    if (L.type == DIRECTIONAL_LIGHT) {
      Ldir = L.dir.normalized() * -1.0f;
    } else if (L.type == POINT_LIGHT) {
      Dir3D tmp = Dir3D(L.pos.x - hitPoint.x, L.pos.y - hitPoint.y,
                        L.pos.z - hitPoint.z);
      float dist2 = tmp.magnitudeSqr();
      maxLightDist = sqrtf(dist2);
      if (maxLightDist > 0.0f)
        Ldir = tmp.normalized();
      else
        continue;
      attenuation = 1.0f / dist2;
    } else if (L.type == SPOT_LIGHT) {
      Dir3D tmp = Dir3D(L.pos.x - hitPoint.x, L.pos.y - hitPoint.y,
                        L.pos.z - hitPoint.z);
      float dist2 = tmp.magnitudeSqr();
      maxLightDist = sqrtf(dist2);
      if (maxLightDist > 0.0f)
        Ldir = tmp.normalized();
      else
        continue;
      attenuation = 1.0f / (dist2);
      Dir3D spotToPoint = Dir3D(hitPoint.x - L.pos.x, hitPoint.y - L.pos.y,
                                hitPoint.z - L.pos.z)
                              .normalized();
      float cosAngle = dot(spotToPoint, L.dir.normalized());
      float ang = acosf(clamp(cosAngle, 0.0f, 1.0f)) * (180.0f / M_PI);
      if (ang > L.angle2) {
        continue;
      } else if (ang > L.angle1) {
        float tfall = (ang - L.angle1) / (L.angle2 - L.angle1);
        attenuation *= (1.0f - tfall);
      }
    }

    // Shadow ray
    Point3D shadowOrigin = hitPoint + N * EPSILON;
    if (isShadowBlocked(shadowOrigin, Ldir, maxLightDist))
      continue;

    // Diffuse contribution
    Color diff = diffuseContribution(L, N, m, Ldir);
    contribution.r += attenuation * diff.r;
    contribution.g += attenuation * diff.g;
    contribution.b += attenuation * diff.b;

    // Specular contribution
    Color spec = specularContribution(L, N, V, m, Ldir);
    contribution.r += attenuation * spec.r;
    contribution.g += attenuation * spec.g;
    contribution.b += attenuation * spec.b;
  }

  // Reflect
  if (depth > 0 && (m.sr > 0.0f || m.sg > 0.0f || m.sb > 0.0f)) {
    Dir3D reflDir = reflect(rayDir, N).normalized();
    Point3D reflOrig = hitPoint + reflDir * EPSILON;
    Color reflCol = evaluateRayTree(reflOrig, reflDir, depth - 1);
    contribution.r += m.sr * reflCol.r;
    contribution.g += m.sg * reflCol.g;
    contribution.b += m.sb * reflCol.b;
  }

  // Refract
  if (depth > 0 && (m.tr > 0.0f || m.tg > 0.0f || m.tb > 0.0f)) {
    Dir3D refrDir = refract(rayDir, N, m.ior);
    if (refrDir.magnitudeSqr() > 0.0f) {
      Point3D refrOrig = hitPoint + refrDir * EPSILON;
      Color refrCol = evaluateRayTree(refrOrig, refrDir, depth - 1);
      contribution.r += m.tr * refrCol.r;
      contribution.g += m.tg * refrCol.g;
      contribution.b += m.tb * refrCol.b;
    }
  }

  // Ambient
  Color amb = ambient(m, 1.0f);
  contribution.r += amb.r;
  contribution.g += amb.g;
  contribution.b += amb.b;

  contribution.r = clamp(contribution.r, 0.0f, 1.0f);
  contribution.g = clamp(contribution.g, 0.0f, 1.0f);
  contribution.b = clamp(contribution.b, 0.0f, 1.0f);

  return contribution;
}

// recursive ray tracing
Color evaluateRayTree(Point3D &origin, Dir3D &rayDir, int depth) {
  HitResult hit = findIntersection(origin, rayDir);

  if (!hit.hit)
    return background_color;

  return applyLightingModel(origin, rayDir, depth, hit.hitPoint, hit.normal,
                            *hit.mat);
}

int main(int argc, char **argv) {

  // Read command line parameters to get scene file
  if (argc < 2 || argc > 3) {
    std::cout << "Usage: ./raytrace scenefile [num_threads]\n";
    return 0;
  }

  std::string sceneFileName = argv[1];

  int numThreads = omp_get_max_threads();
  if (argc == 3) {
    numThreads = std::stoi(argv[2]);
  }
  omp_set_num_threads(numThreads);
  std::cout << "Using " << numThreads << " threads.\n";

  // Parse Scene File
  parseSceneFile(sceneFileName);

  float imgW = img_width, imgH = img_height;
  float halfW = imgW / 2, halfH = imgH / 2;
  float d = halfH / tanf(halfAngleVFOV * (M_PI / 180.0f));

  Image outputImg = Image(img_width, img_height);
  auto t_start = std::chrono::high_resolution_clock::now();

#pragma omp parallel for collapse(2) schedule(dynamic)
  for (int i = 0; i < img_width; i++) {
    for (int j = 0; j < img_height; j++) {
      float u = (halfW - (imgW) * ((i + 0.5) / imgW));
      float v = (halfH - (imgH) * ((j + 0.5) / imgH));
      Point3D p = eye - d * forward + u * right + v * up;
      Dir3D rayDir = (p - eye).normalized();
      Color pixelColor = evaluateRayTree(eye, rayDir, max_depth);
      outputImg.setPixel(i, j, pixelColor);
    }
  }
  auto t_end = std::chrono::high_resolution_clock::now();
  printf("Rendering took %.2f ms\n",
         std::chrono::duration<double, std::milli>(t_end - t_start).count());

  outputImg.write(imgName.c_str());

  if (vertices != nullptr)
    delete[] vertices;
  if (normals != nullptr)
    delete[] normals;
  return 0;
}
