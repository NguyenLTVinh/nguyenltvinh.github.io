// obj_to_scene.cpp
// Compile: g++ -std=c++11 obj_to_scene.cpp -o obj_to_scene

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>

struct Vec3 {
    float x, y, z;
    Vec3(float x=0, float y=0, float z=0) : x(x), y(y), z(z) {}
};

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cout << "Usage: " << argv[0] << " input.obj output.scene\n";
        return 1;
    }

    std::ifstream infile(argv[1]);
    std::ofstream outfile(argv[2]);
    
    if (!infile || !outfile) {
        std::cerr << "Error opening files\n";
        return 1;
    }

    std::vector<Vec3> vertices;
    std::vector<Vec3> normals;
    std::vector<std::string> faces;
    
    Vec3 minBounds(1e30, 1e30, 1e30);
    Vec3 maxBounds(-1e30, -1e30, -1e30);
    
    std::string line;
    bool hasNormals = false;
    
    // Parse OBJ file
    while (std::getline(infile, line)) {
        if (line.empty() || line[0] == '#') continue;
        
        std::istringstream iss(line);
        std::string type;
        iss >> type;
        
        if (type == "v") {
            float x, y, z;
            iss >> x >> y >> z;
            vertices.push_back(Vec3(x, y, z));
            
            // Track bounding box
            minBounds.x = std::min(minBounds.x, x);
            minBounds.y = std::min(minBounds.y, y);
            minBounds.z = std::min(minBounds.z, z);
            maxBounds.x = std::max(maxBounds.x, x);
            maxBounds.y = std::max(maxBounds.y, y);
            maxBounds.z = std::max(maxBounds.z, z);
            
        } else if (type == "vn") {
            float nx, ny, nz;
            iss >> nx >> ny >> nz;
            normals.push_back(Vec3(nx, ny, nz));
            hasNormals = true;
            
        } else if (type == "f") {
            faces.push_back(line);
        }
    }
    
    // Calculate model center and size
    Vec3 center(
        (minBounds.x + maxBounds.x) / 2.0f,
        (minBounds.y + maxBounds.y) / 2.0f,
        (minBounds.z + maxBounds.z) / 2.0f
    );
    
    float sizeX = maxBounds.x - minBounds.x;
    float sizeY = maxBounds.y - minBounds.y;
    float sizeZ = maxBounds.z - minBounds.z;
    float maxSize = std::max({sizeX, sizeY, sizeZ});
    
    // Camera positioning
    float cameraDistance = maxSize * 2.5f;
    Vec3 cameraPos(
        center.x + cameraDistance * 0.866f,  // CHANGED: + instead of -
        center.y + cameraDistance * 0.5f,    
        center.z + cameraDistance * 0.866f   // CHANGED: + instead of -
    );

    // Camera looks AWAY from center (matching your raytracer convention)
    Vec3 cameraDir(
        cameraPos.x - center.x,  // FLIPPED: pos - center instead of center - pos
        cameraPos.y - center.y,
        cameraPos.z - center.z
    );
    float dirLen = sqrt(cameraDir.x*cameraDir.x + cameraDir.y*cameraDir.y + cameraDir.z*cameraDir.z);
    cameraDir.x /= dirLen;
    cameraDir.y /= dirLen;
    cameraDir.z /= dirLen;
    
    // Write scene file
    outfile << "# Converted from OBJ\n";
    outfile << "# Model bounds: (" << minBounds.x << ", " << minBounds.y << ", " << minBounds.z << ") to ("
            << maxBounds.x << ", " << maxBounds.y << ", " << maxBounds.z << ")\n";
    outfile << "# Model center: (" << center.x << ", " << center.y << ", " << center.z << ")\n";
    outfile << "# Model size: " << maxSize << "\n\n";
    
    outfile << "camera_pos: " << cameraPos.x << " " << cameraPos.y << " " << cameraPos.z << "\n";
    outfile << "camera_fwd: " << cameraDir.x << " " << cameraDir.y << " " << cameraDir.z << "\n";
    outfile << "camera_up: 0 1 0\n";
    outfile << "camera_fov_ha: 35\n";
    outfile << "output_image: rendered.png\n\n";
    
    outfile << "directional_light: 0.7 0.8 1  1 -1 -0.5\n";
    outfile << "ambient_light: .2 .2 .2\n";
    outfile << "background: .05 .05 .05\n";
    outfile << "max_depth: 5\n\n";
    
    outfile << "# Ground sphere\n";
    outfile << "material: .75 .75 .75 .75 .75 .75 .3 .3 .3 32 .2 .2 .2 1.5\n";
    outfile << "sphere: " << center.x << " " << (minBounds.y - maxSize * 2) << " " << center.z << " " << (maxSize * 2) << "\n\n";
    
    outfile << "# Mesh data\n";
    outfile << "max_vertices: " << vertices.size() << "\n";
    
    if (hasNormals) {
        outfile << "max_normals: " << normals.size() << "\n";
    }
    
    outfile << "\n";
    
    // Write vertices
    for (const auto& v : vertices) {
        outfile << "vertex: " << v.x << " " << v.y << " " << v.z << "\n";
    }
    
    outfile << "\n";
    
    // Write normals if present
    if (hasNormals) {
        for (const auto& n : normals) {
            outfile << "normal: " << n.x << " " << n.y << " " << n.z << "\n";
        }
        outfile << "\n";
    }
    
    // Material for mesh
    outfile << "material: 0.8 0.2 0.2 0.8 0.2 0.2 .7 .7 .7 64 .1 .1 .1 1.0\n\n";
    
    // Write faces
    for (const auto& faceLine : faces) {
        std::istringstream iss(faceLine);
        std::string f;
        iss >> f; // skip 'f'
        
        std::vector<int> vIndices, nIndices;
        std::string token;
        
        while (iss >> token) {
            int v = -1, vt = -1, vn = -1;
            
            // Parse f formats: v, v/vt, v//vn, v/vt/vn
            size_t slash1 = token.find('/');
            if (slash1 == std::string::npos) {
                v = std::stoi(token);
            } else {
                v = std::stoi(token.substr(0, slash1));
                size_t slash2 = token.find('/', slash1 + 1);
                if (slash2 != std::string::npos) {
                    if (slash2 > slash1 + 1) {
                        vt = std::stoi(token.substr(slash1 + 1, slash2 - slash1 - 1));
                    }
                    vn = std::stoi(token.substr(slash2 + 1));
                } else if (slash1 + 1 < token.length()) {
                    vt = std::stoi(token.substr(slash1 + 1));
                }
            }
            
            vIndices.push_back(v - 1); // Convert to 0-based
            if (vn > 0) nIndices.push_back(vn - 1);
        }
        
        // Triangulate if needed (assuming convex faces)
        for (size_t i = 1; i + 1 < vIndices.size(); ++i) {
            if (hasNormals && nIndices.size() == vIndices.size()) {
                outfile << "normal_triangle: " 
                       << vIndices[0] << " " << vIndices[i] << " " << vIndices[i+1] << " "
                       << nIndices[0] << " " << nIndices[i] << " " << nIndices[i+1] << "\n";
            } else {
                outfile << "triangle: " 
                       << vIndices[0] << " " << vIndices[i] << " " << vIndices[i+1] << "\n";
            }
        }
    }
    
    std::cout << "Conversion complete!\n";
    std::cout << "Vertices: " << vertices.size() << "\n";
    std::cout << "Normals: " << normals.size() << "\n";
    std::cout << "Faces: " << faces.size() << "\n";
    std::cout << "Camera positioned at: (" << cameraPos.x << ", " << cameraPos.y << ", " << cameraPos.z << ")\n";
    std::cout << "Looking at model center: (" << center.x << ", " << center.y << ", " << center.z << ")\n";
    
    return 0;
}