// To Compile: g++ -fsanitize=address -std=c++11 rayTrace_pga.cpp

// For Visual Studios
#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS // For fopen and sscanf
#define _USE_MATH_DEFINES
#endif

// Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION       // only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION // only place once in one .cpp files
#include "image_lib.h" //Defines an image class and a color class

// #3D PGA
#include "PGA_3D.h"

// High resolution timer
#include <chrono>

// Scene file parser
#include "parse_pga.h"

// Small offset
const float EPSILON = 1e-4f;

// C++11 does not have built in clamp in std so this goes here.
template <typename T> T clamp(T val, T minVal, T maxVal) {
  return (val < minVal) ? minVal : (val > maxVal ? maxVal : val);
}

float intersectSphere(Point3D &rayOrigin, Dir3D &rayDir, Point3D &center,
                      float radius) {
  Dir3D L = Dir3D(rayOrigin.x - center.x, rayOrigin.y - center.y,
                  rayOrigin.z - center.z);
  // O + t * D
  float a = dot(rayDir, rayDir);
  float b = 2.0f * dot(rayDir, L);
  float c = dot(L, L) - radius * radius;
  float discr = b * b - 4 * a * c;
  if (discr < 0.0f)
    return -1.0f;
  float sqrtD = sqrtf(discr);
  float t0 = (-b - sqrtD) / (2.0f * a);
  float t1 = (-b + sqrtD) / (2.0f * a);
  // smallest positive t
  float t = -1.0f;
  if (t0 > EPSILON)
    t = t0;
  else if (t1 > EPSILON)
    t = t1;
  return t;
}

int findIntersection(Point3D &rayOrigin, Dir3D &rayDir, float &outT,
                     Point3D &outHit, Dir3D &outNormal) {
  int hitIndex = -1;
  float nearestT = 1e30f;
  for (size_t i = 0; i < spheres.size(); ++i) {
    float t = intersectSphere(rayOrigin, rayDir, spheres[i].center,
                              spheres[i].radius);
    if (t > 0.0f && t < nearestT) {
      nearestT = t;
      hitIndex = (int)i;
    }
  }
  if (hitIndex == -1)
    return -1;
  outT = nearestT;
  outHit = Point3D(rayOrigin.x + rayDir.x * nearestT,
                   rayOrigin.y + rayDir.y * nearestT,
                   rayOrigin.z + rayDir.z * nearestT);
  // normal at hit:
  Sphere &s = spheres[hitIndex];
  Dir3D N = (outHit - s.center).normalized();
  outNormal = N;
  return hitIndex;
}

Dir3D reflect(Dir3D &I, Dir3D &N) {
  float dotIN = dot(I, N);
  Dir3D scaledNormal = 2.0f * dotIN * N;
  return I - scaledNormal;
}

Dir3D refract(Dir3D &I, Dir3D &N, float ior) {
  Dir3D I_norm = I.normalized();
  float cosi = clamp(dot(I_norm, N), -1.0f, 1.0f);
  float nui = 1, nur = ior;
  Dir3D n = N;

  if (cosi < 0) {
    cosi = -cosi;
  } else {
    std::swap(nui, nur);
    n = N * -1.0f;
  }

  float nu = nui / nur;
  float k = 1 - nu * nu * (1 - cosi * cosi);
  if (k < 0)
    return Dir3D(0, 0, 0);

  return (nu * I_norm + (nu * cosi - sqrtf(k)) * n).normalized();
}

Color ambient(Material &m, float scale) {
  return Color(ambient_light.r * m.ar * scale, ambient_light.g * m.ag * scale,
               ambient_light.b * m.ab * scale);
}

Color diffuseContribution(Light &L, Dir3D &N, Material &m, Dir3D &Ldir) {
  float NdotL = std::max(dot(N, Ldir), 0.0f);
  return Color(m.dr * NdotL * L.intensity.r, m.dg * NdotL * L.intensity.g,
               m.db * NdotL * L.intensity.b);
}

Color specularContribution(Light &L, Dir3D &N, Dir3D &V, Material &m,
                           Dir3D &Ldir) {
  Dir3D negLdir = Ldir * -1.0f;
  Dir3D R = reflect(negLdir, N);
  float RdotV = std::max(dot(R, V), 0.0f);
  float specFactor = (m.ns > 0.0f) ? powf(RdotV, m.ns) : 0.0f;
  return Color(m.sr * specFactor * L.intensity.r,
               m.sg * specFactor * L.intensity.g,
               m.sb * specFactor * L.intensity.b);
}

Color evaluateRayTree(Point3D &origin, Dir3D &rayDir, int depth);

Color applyLightingModel(Point3D &origin, Dir3D &rayDir, int depth,
                         Point3D &hitPoint, Dir3D &N, Material &m) {
  Color contribution(0.0f, 0.0f, 0.0f);
  Dir3D V = (origin - hitPoint).normalized();

  for (Light &L : lights) {
    Dir3D Ldir;
    float attenuation = 1.0f;
    float maxLightDist = 1e30f;

    if (L.type == DIRECTIONAL_LIGHT) {
      Ldir = L.dir.normalized() * -1.0f;
    } else if (L.type == POINT_LIGHT) {
      Dir3D tmp = Dir3D(L.pos.x - hitPoint.x, L.pos.y - hitPoint.y,
                        L.pos.z - hitPoint.z);
      float dist2 = tmp.magnitudeSqr();
      maxLightDist = sqrtf(dist2);
      if (maxLightDist > 0.0f)
        Ldir = tmp.normalized();
      else
        continue;
      attenuation = 1.0f / dist2;
    } else if (L.type == SPOT_LIGHT) {
      Dir3D tmp = Dir3D(L.pos.x - hitPoint.x, L.pos.y - hitPoint.y,
                        L.pos.z - hitPoint.z);
      float dist2 = tmp.magnitudeSqr();
      maxLightDist = sqrtf(dist2);
      if (maxLightDist > 0.0f)
        Ldir = tmp.normalized();
      else
        continue;
      attenuation = 1.0f / (dist2);
      // spot angular falloff
      Dir3D spotToPoint = Dir3D(hitPoint.x - L.pos.x, hitPoint.y - L.pos.y,
                                hitPoint.z - L.pos.z)
                              .normalized();
      float cosAngle = dot(spotToPoint, L.dir.normalized());
      float ang = acosf(clamp(cosAngle, 0.0f, 1.0f)) * (180.0f / M_PI);
      if (ang > L.angle2) {
        // outside outer cone -> no contribution
        continue;
      } else if (ang > L.angle1) {
        // between inner and outer -> linear falloff
        float tfall = (ang - L.angle1) / (L.angle2 - L.angle1);
        attenuation *= (1.0f - tfall);
      }
    }

    // shadow ray
    Point3D shadowOrigin = hitPoint + N * EPSILON;
    bool blocked = false;
    for (Sphere &s : spheres) {
      float t = intersectSphere(shadowOrigin, Ldir, s.center, s.radius);
      if (t > 0.0f && t < maxLightDist - EPSILON) {
        blocked = true;
        break;
      }
    }
    if (blocked)
      continue;

    // diffuse contribution
    Color diff = diffuseContribution(L, N, m, Ldir);
    contribution.r += attenuation * diff.r;
    contribution.g += attenuation * diff.g;
    contribution.b += attenuation * diff.b;

    // specular contribution
    Color spec = specularContribution(L, N, V, m, Ldir);
    contribution.r += attenuation * spec.r;
    contribution.g += attenuation * spec.g;
    contribution.b += attenuation * spec.b;
  }

  // reflect
  if (depth > 0 && (m.sr > 0.0f || m.sg > 0.0f || m.sb > 0.0f)) {
    Dir3D reflDir = reflect(rayDir, N).normalized();
    Point3D reflOrig = hitPoint + reflDir * EPSILON;
    Color reflCol = evaluateRayTree(reflOrig, reflDir, depth - 1);
    contribution.r += m.sr * reflCol.r;
    contribution.g += m.sg * reflCol.g;
    contribution.b += m.sb * reflCol.b;
  }

  // refract
  if (depth > 0 && (m.tr > 0.0f || m.tg > 0.0f || m.tb > 0.0f)) {
    Dir3D refrDir = refract(rayDir, N, m.ior);
    if (refrDir.magnitudeSqr() > 0.0f) {
      Point3D refrOrig = hitPoint + refrDir * EPSILON;
      Color refrCol = evaluateRayTree(refrOrig, refrDir, depth - 1);
      contribution.r += m.tr * refrCol.r;
      contribution.g += m.tg * refrCol.g;
      contribution.b += m.tb * refrCol.b;
    }
  }

  // ambient
  Color amb = ambient(m, 1.0f);
  contribution.r += amb.r;
  contribution.g += amb.g;
  contribution.b += amb.b;

  contribution.r = clamp(contribution.r, 0.0f, 1.0f);
  contribution.g = clamp(contribution.g, 0.0f, 1.0f);
  contribution.b = clamp(contribution.b, 0.0f, 1.0f);

  return contribution;
}

// recursive ray tracing
Color evaluateRayTree(Point3D &origin, Dir3D &rayDir, int depth) {
  float t;
  Point3D hitPoint;
  Dir3D N;
  int idx = findIntersection(origin, rayDir, t, hitPoint, N);

  if (idx == -1)
    return background_color;

  Sphere &s = spheres[idx];
  Material &m = s.mat;

  return applyLightingModel(origin, rayDir, depth, hitPoint, N, m);
}

int main(int argc, char **argv) {

  // Read command line parameters to get scene file
  if (argc != 2) {
    std::cout << "Usage: ./a.out scenefile\n";
    return (0);
  }
  std::string sceneFileName = argv[1];

  // Parse Scene File
  parseSceneFile(sceneFileName);

  float imgW = img_width, imgH = img_height;
  float halfW = imgW / 2, halfH = imgH / 2;
  float d = halfH / tanf(halfAngleVFOV * (M_PI / 180.0f));

  Image outputImg = Image(img_width, img_height);
  auto t_start = std::chrono::high_resolution_clock::now();
  for (int i = 0; i < img_width; i++) {
    for (int j = 0; j < img_height; j++) {
      float u = (halfW - (imgW) * ((i + 0.5) / imgW));
      float v = (halfH - (imgH) * ((j + 0.5) / imgH));
      Point3D p = eye - d * forward + u * right + v * up;
      Dir3D rayDir = (p - eye);
      Line3D rayLine = vee(eye, rayDir).normalized();
      Color pixelColor = evaluateRayTree(eye, rayDir, max_depth);
      outputImg.setPixel(i, j, pixelColor);
    }
  }
  auto t_end = std::chrono::high_resolution_clock::now();
  printf("Rendering took %.2f ms\n",
         std::chrono::duration<double, std::milli>(t_end - t_start).count());

  outputImg.write(imgName.c_str());
  return 0;
}
