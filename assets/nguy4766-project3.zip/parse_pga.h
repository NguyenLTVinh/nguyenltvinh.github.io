#ifndef PARSE_PGA_H
#define PARSE_PGA_H

#include "PGA_3D.h"
#include "image_lib.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

struct Material {
  float ar, ag, ab;
  float dr, dg, db;
  float sr, sg, sb;
  float ns;
  float tr, tg, tb;
  float ior;
  Material(float ar_ = 0, float ag_ = 0, float ab_ = 0, float dr_ = 1,
           float dg_ = 1, float db_ = 1, float sr_ = 0, float sg_ = 0,
           float sb_ = 0, float ns_ = 5, float tr_ = 0, float tg_ = 0,
           float tb_ = 0, float ior_ = 1)
      : ar(ar_), ag(ag_), ab(ab_), dr(dr_), dg(dg_), db(db_), sr(sr_), sg(sg_),
        sb(sb_), ns(ns_), tr(tr_), tg(tg_), tb(tb_), ior(ior_) {}
};

struct Sphere {
  Point3D center;
  float radius;
  Material mat;
};

enum LightType { POINT_LIGHT, DIRECTIONAL_LIGHT, SPOT_LIGHT };

struct Light {
  LightType type;
  Color intensity;
  Point3D pos;
  Dir3D dir;
  float angle1;
  float angle2;
  Light(LightType t = POINT_LIGHT, Color c = Color(1, 1, 1))
      : type(t), intensity(c), pos(0, 0, 0), dir(0, 0, 0), angle1(0),
        angle2(0) {}
};

// Defaults
int img_width = 800, img_height = 600;
std::string imgName = "raytraced.png";

Point3D eye = Point3D(0, 0, 0);
Dir3D forward = Dir3D(0, 0, -1).normalized();
Dir3D up = Dir3D(0, 1, 0).normalized();
Dir3D right = Dir3D(-1, 0, 0).normalized();
float halfAngleVFOV = 35.0f;

std::vector<Sphere> spheres;
std::vector<Light> lights;
Color ambient_light = Color(0, 0, 0);
Color background_color = Color(0, 0, 0);
int max_depth = 5;

void parseSceneFile(std::string fileName) {
  std::ifstream in(fileName);
  if (!in) {
    std::cerr << "Error opening scene file: " << fileName << std::endl;
    exit(1);
  }

  std::string line;
  Material currentMat(0, 0, 0, 1, 1, 1, 0, 0, 0, 5, 0, 0, 0,
                      1); // default

  while (std::getline(in, line)) {
    if (line.empty())
      continue;

    size_t firstNon = line.find_first_not_of(" \t");
    if (firstNon == std::string::npos)
      continue;
    if (line[firstNon] == '#')
      continue;

    std::istringstream iss(line);
    std::string cmd;
    iss >> cmd;

    if (cmd == "film_resolution:") {
      iss >> img_width >> img_height;
    } else if (cmd == "output_image:") {
      iss >> imgName;
    } else if (cmd == "camera_pos:") {
      float x, y, z;
      iss >> x >> y >> z;
      eye = Point3D(x, y, z);
    } else if (cmd == "camera_fwd:") {
      float x, y, z;
      iss >> x >> y >> z;
      forward = Dir3D(x, y, z).normalized();
    } else if (cmd == "camera_up:") {
      float x, y, z;
      iss >> x >> y >> z;
      up = Dir3D(x, y, z).normalized();
    } else if (cmd == "camera_fov_ha:") {
      iss >> halfAngleVFOV;
    } else if (cmd == "sphere:") {
      float x, y, z, r;
      if (iss >> x >> y >> z >> r) {
        Sphere s;
        s.center = Point3D(x, y, z);
        s.radius = r;
        s.mat = currentMat;
        spheres.push_back(s);
      }
    } else if (cmd == "material:") {
      // ar ag ab dr dg db sr sg sb ns tr tg tb ior
      float ar, ag, ab, dr, dg, db, sr, sg, sb, ns, tr, tg, tb, ior;
      if (iss >> ar >> ag >> ab >> dr >> dg >> db >> sr >> sg >> sb >> ns >>
          tr >> tg >> tb >> ior) {
        currentMat =
            Material(ar, ag, ab, dr, dg, db, sr, sg, sb, ns, tr, tg, tb, ior);
      } else {
        std::cerr << "Warning: malformed material line: " << line << std::endl;
      }
    } else if (cmd == "ambient_light:") {
      float r, g, b;
      iss >> r >> g >> b;
      ambient_light = Color(r, g, b);
    } else if (cmd == "background:") {
      float r, g, b;
      iss >> r >> g >> b;
      background_color = Color(r, g, b);
    } else if (cmd == "point_light:") {
      float r, g, b, x, y, z;
      if (iss >> r >> g >> b >> x >> y >> z) {
        Light L(POINT_LIGHT, Color(r, g, b));
        L.pos = Point3D(x, y, z);
        lights.push_back(L);
      }
    } else if (cmd == "directional_light:") {
      float r, g, b, x, y, z;
      if (iss >> r >> g >> b >> x >> y >> z) {
        Light L(DIRECTIONAL_LIGHT, Color(r, g, b));
        L.dir = Dir3D(x, y, z).normalized();
        lights.push_back(L);
      }
    } else if (cmd == "spot_light:") {
      // r g b px py pz dx dy dz angle1 angle2
      float r, g, b, px, py, pz, dx, dy, dz, a1, a2;
      if (iss >> r >> g >> b >> px >> py >> pz >> dx >> dy >> dz >> a1 >> a2) {
        Light L(SPOT_LIGHT, Color(r, g, b));
        L.pos = Point3D(px, py, pz);
        L.dir = Dir3D(dx, dy, dz).normalized();
        L.angle1 = a1;
        L.angle2 = a2;
        lights.push_back(L);
      }
    } else if (cmd == "max_depth:") {
      iss >> max_depth;
      if (max_depth < 0)
        max_depth = 0;
    }
  }

  forward = forward.normalized();
  right = cross(up, forward).normalized();
  up = cross(forward, right).normalized();

  std::cout << "Scene parsed. Spheres: " << spheres.size()
            << ", Lights: " << lights.size() << ", ambient: ("
            << ambient_light.r << "," << ambient_light.g << ","
            << ambient_light.b << ")"
            << ", background: (" << background_color.r << ","
            << background_color.g << "," << background_color.b << ")\n";
}

#endif
